"""Extract only source-supported, image-coordinate layers from the supplied PDF map.

The source is the raster embedded on printed page 76 (part 7, PDF page 15).
No georeferencing, land parcel inference, or flood buffer is attempted.
"""
from pathlib import Path
import glob
import json
import hashlib

import fiona
import numpy as np
import rasterio.features
from PIL import Image
from scipy import ndimage as ndi
from shapely.geometry import shape, mapping
from shapely.ops import unary_union


OUT = Path(__file__).resolve().parent
SOURCE = OUT / "review/part7_page15_xref1879.png"
STANDALONE_SOURCE = OUT / "review/part9_xref56.png"
source_sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
if STANDALONE_SOURCE.exists():
    assert hashlib.sha256(STANDALONE_SOURCE.read_bytes()).hexdigest() == source_sha
im = np.array(Image.open(SOURCE).convert("RGB"))
h, w, _ = im.shape
r, g, b = (im[:, :, j].astype(np.int16) for j in range(3))

# Thick black source outline is one closed, connected component. Keep its
# existing raster pixels and fill its interior; never extrapolate the contour.
ink = (r < 100) & (g < 100) & (b < 100)
cc, count = ndi.label(ink)
counts = np.bincount(cc.ravel())
counts[0] = 0
outer_ink = cc == counts.argmax()
boundary = ndi.binary_fill_holes(outer_ink)
assert boundary.sum() > 100_000

# Only the recognizable green fill of existing fields. Other greens, shadows,
# roads, river pixels, and field boundaries remain exactly as in the source.
fields_raw = (
    boundary
    & (r >= 115) & (r <= 215)
    & (g >= 145) & (g <= 230)
    & (g - r >= 11) & (g - r <= 42)
    & (r - b >= 5) & (r - b <= 40)
)
groups, n = ndi.label(fields_raw)
sizes = np.bincount(groups.ravel())
fields = fields_raw & (sizes[groups] >= 6)

# A policy intervention on already depicted northern fields near the existing
# east-west corridor. This is a candidate for irrigation/production upgrades,
# not a new agricultural parcel or an approved land-use conversion.
yy, xx = np.indices((h, w))
upgrade = fields & (xx >= 355) & (xx <= 500) & (yy >= 62) & (yy <= 174)
protect = fields & ~upgrade

# Source-blue pixels are retained as a visual reference, not a centerline or
# a measured flood-risk area. The source itself stays unchanged beneath.
blue_pixels = boundary & (b - r >= 24) & (b - g >= 11) & (b >= 145) & (r <= 225)

rgba = np.dstack((im, np.where(boundary, 255, 0).astype(np.uint8)))
Image.fromarray(rgba).save(OUT / "basemap_clipped.png")

result = rgba.copy()
for mask, color, alpha in [
    (protect, np.array([25, 98, 47], dtype=np.float32), .52),
    (upgrade, np.array([122, 203, 98], dtype=np.float32), .52),
]:
    source_rgb = result[:, :, :3][mask].astype(np.float32)
    result[:, :, :3][mask] = np.rint((1 - alpha) * source_rgb + alpha * color).astype(np.uint8)

# The composited map is purely map content: no legend, scale, text, or title.
result[~boundary, 3] = 0
base = Image.fromarray(result)
base.resize((3200, 2260), Image.Resampling.NEAREST).save(
    OUT / "alternative_1_partial_300dpi.png", dpi=(300, 300)
)
# A compact print layout of the same exact source pixels, with only transparent
# padding around the original outline. No labels or new geographic content.
ys, xs = np.where(boundary)
pad = 10
crop = tuple(map(int, (max(0, xs.min() - pad), max(0, ys.min() - pad),
        min(w, xs.max() + pad + 1), min(h, ys.max() + pad + 1))))
compact = base.crop(crop)
compact.resize((compact.width * 6, compact.height * 6), Image.Resampling.NEAREST).save(
    OUT / "alternative_1_map_300dpi.png", dpi=(300, 300)
)

gpkg = OUT / "ghat_alternative_1_image_coords.gpkg"
if gpkg.exists():
    gpkg.unlink()


def polygons(mask, min_area=0):
    result = []
    for geom, value in rasterio.features.shapes(mask.astype("uint8"), mask=mask):
        if value:
            poly = shape(geom)
            if poly.area >= min_area:
                result.append(poly)
    return result


def layer(name, geometries, description, source_page, status):
    schema = {"geometry": "Polygon", "properties": {
        "id": "int", "class_ar": "str", "page": "str", "status": "str"
    }}
    with fiona.open(gpkg, "w", driver="GPKG", layer=name, schema=schema,
                    encoding="UTF-8") as dst:
        for i, geom in enumerate(geometries, 1):
            dst.write({"geometry": mapping(geom), "properties": {
                "id": i, "class_ar": description, "page": source_page,
                "status": status
            }})


layer("existing_display_boundary", polygons(boundary, 1000),
      "حد العرض الخارجي الظاهر بالخريطة", "76", "pixel-traced; not cadastral")
layer("existing_green_pixels", polygons(fields, 6),
      "رقع خضراء ظاهرة في المصدر", "76", "color-derived; needs field check")
layer("existing_blue_pixels", polygons(blue_pixels, 2),
      "بكسلات زرقاء للمجاري في المصدر", "76", "reference pixels; not flood zone")
layer("proposed_farm_protection", polygons(protect, 6),
      "حماية الرقع الزراعية المرئية", "76; 75; 98", "candidate policy")
layer("proposed_sustainable_upgrade", polygons(upgrade, 6),
      "ترقية الري والإنتاج داخل الرقع القائمة شمالاً", "76; 75; 98", "candidate policy")

stats = {
    "source_image_size_pixels": [w, h],
    "coordinate_system": "image pixels, origin upper-left, x right, y down; no geographic CRS",
    "source_page_printed": 76,
    "source_sha256": source_sha,
    "standalone_part_9_identical": STANDALONE_SOURCE.exists(),
    "boundary_pixels": int(boundary.sum()),
    "source_green_pixels_identified": int(fields.sum()),
    "candidate_upgrade_pixels": int(upgrade.sum()),
    "candidate_protection_pixels": int(protect.sum()),
    "output_pixel_size": [3200, 2260],
    "compact_map_crop_source_pixels": list(crop),
    "compact_output_pixel_size": [compact.width * 6, compact.height * 6],
    "effective_native_resolution": [w, h],
    "geographic_areas_computed": False,
    "new_roads_or_wadis_added": False,
    "alpha_outside_boundary": bool(np.all(result[~boundary, 3] == 0)),
    "rgb_outside_overlay_equal_to_source": bool(
        np.array_equal(result[:, :, :3][boundary & ~fields], im[boundary & ~fields])
    ),
}
(OUT / "validation_metrics.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2))
print(json.dumps(stats, ensure_ascii=False, indent=2))
